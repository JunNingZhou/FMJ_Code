#include "NuMicro.h"
#include <stdio.h>
#include <string.h>

#include "mcuNet_FMD_Addr.h"

/*
uint32_t FMDOutPutStatus(void)
 {
	uint8_t auPkt[] = { 
		YOURMAC, 
	  MYMAC ,
    VLD,
		//  //总长度 真实udp包长度 +28(或包帧长度-14) 
		LEN1St, //data[16], data[17]
		IFTU,
		//CheckSum1
		CKSt,   //
		//0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		//长度  真实udp包长度 + 8 (或包帧长度-34)
		LEN2St, //	data[38] ; data[39]
		//CheckSum2
		0x00,  0x00,
	  0, 0, 0, 0, 
	  0, 0, 0, 0, 
		ADDRTAG,
		
		
	};
   return EMAC_SendPkt(auPkt, sizeof(auPkt));
}
*/
