#ifndef  _MCU_NET_ADDR_H_
#define  _MCU_NET_ADDR_H_

//�����ֶ�

//9201
//���ж���Ϊ��ʾ��������������ȷ
#define Addr 0xC9

#define MYMAC0 0x02
#define MYMAC1 0x02
#define MYMAC2 0x02
#define MYMAC3 0x02
#define MYMAC4 0x02
#define MYMAC5 Addr

//9200
//192.168.5.xx
#define YOURIP0  0xC0
#define YOURIP1  0xA8
#define YOURIP2  0x05
#define YOURIP3  0xC8

#define MYIP0  0xC0
#define MYIP1  0xA8
#define MYIP2  0x05
#define MYIP3  Addr

// YOURPORT 9200 MYPORT 9201
// Դport Ŀ��port
#define PORT  0x23,0xF1,0x23,0xF0

extern volatile uint8_t g_au8YourMacAddr[6];

#define YOURMAC	g_au8YourMacAddr[0], g_au8YourMacAddr[1], g_au8YourMacAddr[2], g_au8YourMacAddr[3], g_au8YourMacAddr[4], g_au8YourMacAddr[5]

#define MYMAC	MYMAC0,MYMAC1,MYMAC2,MYMAC3,MYMAC4,MYMAC5

#define YOURIP	YOURIP0,YOURIP1,YOURIP2,YOURIP3

#define MYIP	MYIP0,MYIP1,MYIP2,MYIP3

#define VLD		0x08,0x00,0x45,0x00

#define IFTU	0x00, 0x00, 0x40, 0x00, 0x80, 0x11
	

#define ADDRTAG	Addr, 0x00, 0x00, 0x00


#define LEN112	 0x00, 0x28		//ʵ�����ݳ��� 12 + 28	60
#define LEN212	 0x00, 0x14		//ʵ�����ݳ��� 12 + 8

#define LEN116	 0x00, 0x2C		//											64
#define LEN216	 0x00, 0x18

#define LEN120	 0x00, 0x30
#define LEN220	 0x00, 0x1C

#define LEN124	 0x00, 0x34
#define LEN224	 0x00, 0x20

#define LEN128	 0x00, 0x38
#define LEN228	 0x00, 0x24

#define LEN132	 0x00, 0x3C
#define LEN232	 0x00, 0x28

#define LEN136	 0x00, 0x40
#define LEN236	 0x00, 0x2C

#define LEN1Msg	 0x00, 0x4C
#define LEN2Msg	 0x00, 0x38

#define LEN1St	 0x00, 0x84
#define LEN2St	 0x00, 0x70

#define LEN1CONF  0x01, 0x68 
#define LEN2CONF  0x01, 0x54

/*
	4500 LEN 0000 4000 8011 CK(0)    
	NEW C0A8 05C9 C0A8 05C8	
	OLD C0A8 0511 C0A8 0502
	--------------------------------
	4500 + 0 + 4000 +8011 + MYIP + YOUIP = 2 91F2
	+LEN112 = 2 91F2 + 0028 = 2 921A => 921C => 6D E3				2 9074 + 0028 =>2 909C=>909E
	+LEN116 = 2 91F2 + 002C = 2 921E => 9220 => 6D DF
	+LEN120 = 2 91F2 + 0030 = 2 9222 => 9224 => 6D DB
	+LEN124 = 2 91F2 + 0034 = 2 9226 => 9228 => 6D D7
	+LEN128 = 2 91F2 + 0038 = 2 922A =>	922C => 6D D3
	+LEN132 = 2 91F2 + 003C = 2 922E => 9230 => 6D CF
	+LEN136 = 2 91F2 + 0040 = 2 9232 => 9234 => 6D CB
	+LEN1Msg = 2 91F2 + 004C = 2 923E => 9240 => 6D BF
	+LEN1St = 2 91F2 + 0084 = 2 9276 => 9278 => 6D 87
	+LEN1CONF = 2 91F2 + 0168 = 2 935A => 935C => 6C A3
*/

#define CK12  		0x6D, 0xE3 //0x6F, 0x6B
#define CK16  		0x6D, 0xDF //0x6F, 0x67
#define CK20  		0x6D, 0XDB //0x6F, 0x63
#define CK24  		0x6D, 0xD7 //0x6F, 0x5F
#define CK28  		0x6D, 0xD3 //0x6F, 0x5B
#define CK32  		0x6D, 0xCF //0x6F, 0x57
#define CK36			0x6D, 0xCB
#define CKMsg  		0x6D, 0xBF //0x6F, 0x47
#define CKSt  		0x6D, 0x87 //0x6F, 0x4F 
#define CKCONF  	0x6C, 0xA3 //0x6E, 0xF7

#define FHZMAX	100000 //������Ƶ��

#endif  /* _NET_ADDR_H_ */
