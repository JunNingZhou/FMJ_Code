#include "NuMicro.h"
#include <stdio.h>
#include <string.h>

/*
void QEI0_IRQHandler(void)
{
    if (QEI_GET_INT_FLAG(QEI0, QEI_STATUS_CMPF_Msk)) {

          QEI_CLR_INT_FLAG(QEI0, QEI_STATUS_CMPF_Msk);
    

    }
}
*/

/*
void QEI1_IRQHandler(void)
{
    if (QEI_GET_INT_FLAG(QEI1, QEI_STATUS_CMPF_Msk)) {

          QEI_CLR_INT_FLAG(QEI1, QEI_STATUS_CMPF_Msk);
    

    }
}
*/

