#include <stdio.h>
#include "NuMicro.h"
#include "mcu_DataStruct.h"

const FMDrivePara CONF_orig = {
	.EMACTime = 10, 	//	若外部干扰致使网络未连接时,网络重启时间 设置  （探测后可设定）
	.UPTime = 2, 	//	下位机空闲时间到达时,主动发送状态到上位机 设置  （探测后可设定）
	.InitTime = 120 , 	//	下位机重新初始化稳定下位机时间(预防外部干扰用) 设置  （探测后可设定）
	.ADTime = 10 , 	//	AD采样间隔  探测后可设定
	.M1_AXIS = 10000,
	.M2_AXIS = 2000,
	.M3_AXIS = 10000,
	.M4_AXIS = 10000,
	.M5_AXIS = 10000,
	.M6_AXIS = 10000,
	.M7_AXIS = 10000,
	.M8_AXIS = 10000,
	.M1_DIA = 56.000, 
	.M2_DIA = 140.000,
	.M3_DIA = 56.000,
	.M4_DIA = 56.000,
	.M5_DIA = 56.000,
	.M6_DIA = 56.000,
	.M7_DIA = 56.000,
	.M8_DIA = 56.000,
	.M1_FHZ = 60000, 
	.M2_FHZ = 10000,
	.M3_FHZ = 80000,
	.M4_FHZ = 40000,
	.M5_FHZ = 20000,
	.M6_FHZ = 10000,
	.M7_FHZ = 10000,
	.M8_FHZ = 10000,
	.DownRollDrop = 30,
	.LaminatedPaperCount = 0,
	.LastPaperLength = 0,
	.LastOverLapLength = 0,
	.LaminateHeatTemperature = 100,
	.Heat_Fhz = 3000,
	.FeiDaMotorRetreatFHZ = 30000,
	.PaperPlateRiseTimeAlarm = 5,
	.PlateHighDetectionTime = 2,
};

FMDrivePara CONF = {
	.EMACTime = 10, 	//	若外部干扰致使网络未连接时,网络重启时间 设置  （探测后可设定）
	.UPTime = 2, 	//	下位机空闲时间到达时,主动发送状态到上位机 设置  （探测后可设定）
	.InitTime = 120 , 	//	下位机重新初始化稳定下位机时间(预防外部干扰用) 设置  （探测后可设定）
	.ADTime = 10 , 	//	AD采样间隔  探测后可设定
	.M1_AXIS = 10000,
	.M2_AXIS = 2000,
	.M3_AXIS = 10000,
	.M4_AXIS = 10000,
	.M5_AXIS = 10000,
	.M6_AXIS = 200,
	.M7_AXIS = 160000,
	.M8_AXIS = 31000,
	.M1_DIA = 56.000, //单位mm
	.M2_DIA = 140.000,
	.M3_DIA = 56.000,
	.M4_DIA = 56.000,
	.M5_DIA = 56.000,
	.M6_DIA = 0,
	.M7_DIA = 56.000,
	.M8_DIA = 56.000,
	.M1_FHZ = 60000, 
	.M2_FHZ = 10000,
	.M3_FHZ = 80000,
	.M4_FHZ = 40000,
	.M5_FHZ = 20000,
	.M6_FHZ = 10000,
	.M7_FHZ = 10000,
	.M8_FHZ = 10000,
	.DownRollDrop = 30,
	.LaminatedPaperCount = 0,
	.LastPaperLength = 320000,
	.LastOverLapLength = 3000,
	.LaminateHeatTemperature = 100,
	.Heat_Fhz = 3000,
	.FeiDaMotorRetreatFHZ = 36000,
	.PaperPlateRiseTimeAlarm = 5,
	.PlateHighDetectionTime = 2,
};

