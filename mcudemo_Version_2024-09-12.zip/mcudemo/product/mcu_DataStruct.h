#ifndef  _MCU_DATA_STRUCT_H_
#define  _MCU_DATA_STRUCT_H_

#include <stdio.h>

#ifdef RVDS_ARMCM4_NUC4xx
#include "arm_math.h"
#endif

typedef struct FMDrive {
	uint32_t EMACTime; //若外部干扰致使网络未连接时,网络重启时间 设置  （探测后可设定）
	uint32_t UPTime; //下位机空闲时间到达时,主动发送状态到上位机 设置  （探测后可设定）
	uint32_t InitTime; //下位机重新初始化稳定下位机时间(预防外部干扰用) 设置  （探测后可设定）
	uint32_t ADTime; //AD采样间隔  探测后可设定
  uint32_t M1_AXIS;	//	电机M1的轴细分
  uint32_t M2_AXIS;
  uint32_t M3_AXIS;
  uint32_t M4_AXIS;
  uint32_t M5_AXIS;
  uint32_t M6_AXIS;
  uint32_t M7_AXIS;
  uint32_t M8_AXIS;
	float64_t M1_DIA;
	float64_t M2_DIA;
	float64_t M3_DIA;
	float64_t M4_DIA;
	float64_t M5_DIA;
	float64_t M6_DIA;
	float64_t M7_DIA;
	float64_t M8_DIA;
  uint32_t M1_FHZ;	
  uint32_t M2_FHZ;
  uint32_t M3_FHZ;
  uint32_t M4_FHZ;
  uint32_t M5_FHZ;
  uint32_t M6_FHZ;
  uint32_t M7_FHZ;
  uint32_t M8_FHZ;
	uint32_t DownRollDrop;
	uint32_t LaminatedPaperCount;
	uint32_t LastPaperLength;
	uint32_t LastOverLapLength;
	uint32_t LaminateHeatTemperature;
	uint32_t Heat_Fhz;
	uint32_t FeiDaMotorRetreatFHZ;
	uint32_t PaperPlateRiseTimeAlarm;
	uint32_t PlateHighDetectionTime;
} FMDrivePara;



#endif

