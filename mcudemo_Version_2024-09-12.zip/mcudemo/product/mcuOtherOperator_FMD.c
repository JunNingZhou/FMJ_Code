#include <stdio.h>
#include "mcuOtherOperator_FMD.h"
#include "NuMicro.h"
#include "mcuID_FMD.h"
#include "mcuCmd_FMD.h"
#include "mcuNet_FMD_Addr.h"
#include "mcu_DataStruct.h"
#include "mcuNet_FMD.h"

void FeiDaMotorForward(void)
{
	EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, CONF.M5_FHZ, 50);
	EPWM_EnableOutput(C_M5_PWM, C_M5_PUL_MASK);
	P_C_M5_DIR = 0;
	P_C_M5_EN = 0;
	EPWM_Start(C_M5_PWM, C_M5_PUL_MASK);
}

void FeiDaMotorRetreat(void)
{
	EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, CONF.FeiDaMotorRetreatFHZ, 50);
	EPWM_EnableOutput(C_M5_PWM, C_M5_PUL_MASK);
	P_C_M5_DIR = 0;
	P_C_M5_EN = 0;
	EPWM_Start(C_M5_PWM, C_M5_PUL_MASK);
}

void FeiDaMotorStop()
{
	EPWM_Stop(C_M5_PWM, C_M5_PUL_MASK);
	EPWM_DisableOutput(C_M5_PWM, C_M5_PUL_MASK);
	P_C_M5_EN = 1;
}

void f_MotorStop(uint32_t nWhich)
{																	
	switch (nWhich)
  {
		case 0:{
			EPWM_Stop(C_M2_PWM, C_M2_PUL_MASK);
			EPWM_DisableOutput(C_M2_PWM, C_M2_PUL_MASK);
			P_C_M2_EN = 1;
			
			EPWM_Stop(C_M1_PWM, C_M1_PUL_MASK);
			EPWM_DisableOutput(C_M1_PWM, C_M1_PUL_MASK);
			P_C_M1_EN = 1;
	
			EPWM_Stop(C_M3_PWM, C_M3_PUL_MASK);
			EPWM_DisableOutput(C_M3_PWM, C_M3_PUL_MASK);
			P_C_M3_EN = 1;
			
			EPWM_Stop(C_M4_PWM, C_M4_PUL_MASK);
			EPWM_DisableOutput(C_M4_PWM, C_M4_PUL_MASK);
			P_C_M4_EN = 1;
			
			//EPWM_Stop(C_M5_PWM, C_M5_PUL_MASK);
			//EPWM_DisableOutput(C_M5_PWM, C_M5_PUL_MASK);			
			//P_C_M5_EN = 1;
		}
			break;
		case 4:{
			EPWM_Stop(C_M2_PWM, C_M2_PUL_MASK);
			EPWM_DisableOutput(C_M2_PWM, C_M2_PUL_MASK);
			P_C_M2_EN = 1;
			
			EPWM_Stop(C_M1_PWM, C_M1_PUL_MASK);
			EPWM_DisableOutput(C_M1_PWM, C_M1_PUL_MASK);
			P_C_M1_EN = 1;
	
			EPWM_Stop(C_M3_PWM, C_M3_PUL_MASK);
			EPWM_DisableOutput(C_M3_PWM, C_M3_PUL_MASK);
			P_C_M3_EN = 1;
			
			EPWM_Stop(C_M4_PWM, C_M4_PUL_MASK);
			EPWM_DisableOutput(C_M4_PWM, C_M4_PUL_MASK);
			P_C_M4_EN = 1;
		}
			break;
  	case ID_M1STOP:{
			EPWM_Stop(C_M1_PWM, C_M1_PUL_MASK);
			EPWM_DisableOutput(C_M1_PWM, C_M1_PUL_MASK);
			P_C_M1_EN = 1;
		}
  		break;
  	case ID_M2STOP:{
			EPWM_Stop(C_M2_PWM, C_M2_PUL_MASK);
			EPWM_DisableOutput(C_M2_PWM, C_M2_PUL_MASK);
			P_C_M2_EN = 1;
		}
  		break;
		case ID_M3STOP:{
			EPWM_Stop(C_M3_PWM, C_M3_PUL_MASK);
			EPWM_DisableOutput(C_M3_PWM, C_M3_PUL_MASK);
			P_C_M3_EN = 1;
		}
  		break;
		case ID_M4STOP:{
			EPWM_Stop(C_M4_PWM, C_M4_PUL_MASK);
			EPWM_DisableOutput(C_M4_PWM, C_M4_PUL_MASK);
			P_C_M4_EN = 1;
		}
  		break;
		case ID_M5STOP:{
			EPWM_Stop(C_M5_PWM, C_M5_PUL_MASK);
			EPWM_DisableOutput(C_M5_PWM, C_M5_PUL_MASK);
			P_C_M5_EN = 1;
		}
  		break;
  	default:
  		break;
  }
}
void f_MotorRun(uint32_t nWhich,uint32_t nFHz,uint32_t nDir)
{	
	switch (nWhich)
  {
  	case ID_M1RUN:{
			EPWM_ConfigOutputChannel(C_M1_PWM, C_M1_PUL, nFHz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
			EPWM_EnableOutput(C_M1_PWM, C_M1_PUL_MASK);//�������pwm�����
			P_C_M1_EN = 0;
			P_C_M1_DIR = nDir;
			EPWM_Start(C_M1_PWM, C_M1_PUL_MASK);			
		}
  		break;
  	case ID_M2RUN:{
			EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, nFHz, 50);//������
			EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
			P_C_M2_EN = 0;
			P_C_M2_DIR = nDir;
			EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
		}
  		break;
		case ID_M3RUN:{
			EPWM_ConfigOutputChannel(C_M3_PWM, C_M3_PUL, nFHz, 50);//ֽ�̵��
			EPWM_EnableOutput(C_M3_PWM, C_M3_PUL_MASK);
			P_C_M3_EN = 0;
			P_C_M3_DIR = nDir;
			EPWM_Start(C_M3_PWM, C_M3_PUL_MASK);		
		}
  		break;
		case ID_M4RUN:{
			EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, nFHz, 50);//��ֽ���
			EPWM_EnableOutput(C_M4_PWM, C_M4_PUL_MASK);
			P_C_M4_EN = 0;
			P_C_M4_DIR = nDir;
			EPWM_Start(C_M4_PWM, C_M4_PUL_MASK);
		}
  		break;
		case ID_M5RUN:{
			EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, nFHz, 50);
			EPWM_EnableOutput(C_M5_PWM, C_M5_PUL_MASK);
			P_C_M5_EN = 0;
			P_C_M5_DIR = nDir;
			EPWM_Start(C_M5_PWM, C_M5_PUL_MASK);
		}
  		break;
  	default:
  		break;
  }
}

void Init_Machine(void) 
{
	FeiDaMotorForward();
	//if(P_C_INPUT_11 == 0) { // ��ֽ��������⵽1������ȱ�ڴ���Ҫ�˶�����ȱ�ڴ�
	f_MotorRun(ID_M1RUN,CONF.M1_FHZ,0);
	//}
	
	if(P_C_OUT_2 == 1) {
		P_C_OUT_2 = 0;
	}
	if(P_C_OUT_3 == 0) {
		P_C_OUT_3 = 1;
	}	
}

void f_AllMachineStop(void)
{
	f_MotorStop(4);
						
	if(P_C_OUT_5 == 0) {
		P_C_OUT_5 = 1;
	}
						
	P_C_OUT_2 = 0;
	P_C_OUT_3 = 1;
	WriteConfig_NoSendUdp();
}

//-----------------------------------------------
