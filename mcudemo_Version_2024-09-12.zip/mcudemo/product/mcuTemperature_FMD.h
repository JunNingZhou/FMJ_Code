#ifndef MCU_TEMPERATURE_FMD
#define MCU_TEMPERATURE_FMD


#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <arm_math.h>

extern double g_Arr_CV[271];

#define __TEMPERATURE_RANGE__ 5

extern int32_t f_GetTemperatureFrom(const uint32_t u32AD);


#define KP  1.0f
#define KI  0.1f
#define KD 	0.01f

// ���峣��
extern float32_t f32PreviousError;//0.0f
extern float32_t f32Integral;// 0.0f;

extern void f_PIDInit(void);
extern uint32_t f_PIDCalulate(float32_t f64CurrTemp);

extern uint32_t f_CalulateDuty(uint32_t u32Temp);


#endif //MCU_TEMPERATURE_FMD

