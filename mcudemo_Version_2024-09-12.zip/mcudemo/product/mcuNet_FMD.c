#include "NuMicro.h"
#include <stdio.h>
#include <string.h>

#include "mcuID_FMD.h"

#include "mcuCmd_FMD.h"
#include "mcuNet_FMD.h"
#include "mcuNet_FMD_Addr.h"
#include "mcuTemperature_FMD.h"
#include "mcu_DataStruct.h"
#include "mcuOtherOperator_FMD.h"

/*
YOURMAC							MYMAC							 VLD
54 ee 75 a8 32 1d   02 02 02 02 02 06  08 00 45 00
LEN112  IFTU								 CK12		MYIP				  YOURIP
00 44   00 00 40 00 80 11   6f 50   c0 a8 05 06   c0 a8 05 02 
PORT					LEN212	
23 2b 23 2b   00 30   00 00 
DATA
00 00 00 00 00 00 00 00  06 00 00 00 00 00 00 00 
00 00 00 00 f8 0f 00 00  ba 20 00 00 a7 1d 00 00 
a7 1d 00 00 00 00 00 00   

	
//����һ���������ݵ�����Ŀ�ĵ�UDP��ʾ��		
uint8_t auPkt[] = { 		
		YOURMAC, 
		MYMAC ,			
		VLD,
		//  //�ܳ��� ��ʵudp������ +28(���֡����-14) 
		LEN112, //data[16], data[17]
		IFTU,
		//CheckSum1
		CK12,   //0x00, 0x00,
		MYIP,
		YOURIP,
		PORT,
		//����  ��ʵudp������ + 8 (���֡����-34)
		LEN212, //	data[38] ; data[39]
		0x00,  0x00,

		0x88,0x88,0x88,0x88,
		0, 0, 0, 0, 
		ADDRTAG,
};			
EMAC_SendPkt(auPkt, sizeof(auPkt));
				
*/

uint32_t FMDEnterTestMode(void)
{
	g_iSchema = SCHEMA_TESTMODE;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		ENTERTESTMODE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t FMDExitTestMode(void)
{
	g_iSchema = SCHEMA_WORKMODE;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		EXITTESTMODE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}


uint32_t foo(void)
{
	uint32_t i =gP0;
	//UDP��:
  uint8_t auPkt[] = {
    YOURMAC,
    MYMAC,
    VLD,	// 0x08,0x00,0x45,0x00
    //�ܳ��� ��ʵudp������ +28(���֡����-14)
    LEN112, // data[16], data[17]
    IFTU,
    // CheckSum1
    CK12, // 0x00, 0x00,
    MYIP,
    YOURIP,
    PORT,	//Դ�˿ں�Ŀ��˿�  �����϶���һ�µ�
    // ����  ��ʵudp������ + 8 (���֡����-34)
    LEN212, //	data[38] ; data[39]
     // CheckSum2
    0x00,
    0x00,
    FOO_ID,
    i,
	  0,
    0,
    0,
    ADDRTAG, //ZHOU:������
  };
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}

uint32_t bar(void)
{
  CLK_SysTickLongDelay(100);
  uint8_t auPkt[] = {
     YOURMAC,
     MYMAC,
     VLD,
		//�ܳ��� ��ʵudp������ +28(���֡����-14) ZHOU:���ݳ���+28
     LEN112, // data[16], data[17]
     IFTU,
		// CheckSum1
     CK12, // 0x00, 0x00,
     MYIP,
     YOURIP,
     PORT,
		// ����  ��ʵudp������ + 8 (���֡����-34   ZHOU:���ݳ���+8
     LEN212, //	data[38] ; data[39]
     // CheckSum2
     0x00,
     0x00,
     BAR_ID,
     0,
     0,
     0,
     0,
     ADDRTAG,
  };
  return EMAC_SendPkt(auPkt, sizeof(auPkt));
}


//-------------------------------------------------
uint32_t Clear_Alarm(void) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		CLEAR_ALARM_CODE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_AlarmCode)&0xFF, (g_AlarmCode>>8)&0xFF,(g_AlarmCode>>16)&0xFF,(g_AlarmCode>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
//-------------------------------------------------
/*
	0--ʹ��	1--ֹͣʹ��
	0--��ʱ�� 1˳ʱ��
*/
uint32_t Motor1_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M1_FHZ:gP0;//M1_BaseParam.fr;
	if(nFhz > FHZMAX){
		nFhz = 10000;
	}
	uint32_t nDir = gP1 == 0 ? 0:1;
	EPWM_ConfigOutputChannel(C_M1_PWM, C_M1_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M1_PWM, C_M1_PUL_MASK);//�������pwm�����
	P_C_M1_EN = 0;
	P_C_M1_DIR = nDir;
	EPWM_Start(C_M1_PWM, C_M1_PUL_MASK);
		
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M1RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t Motor1_Stop(void)
{
	EPWM_Stop(C_M1_PWM, C_M1_PUL_MASK);
	EPWM_DisableOutput(C_M1_PWM, C_M1_PUL_MASK);
	P_C_M1_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M1STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor2_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M2_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, nFhz, 50);//���� M2ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);//�������pwm�����
	P_C_M2_EN = 0;
	P_C_M2_DIR = nDir;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M2RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor2_Stop(void)
{
	EPWM_Stop(C_M2_PWM, C_M2_PUL_MASK);
	EPWM_DisableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M2STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor3_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M3_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
		if(P_C_INPUT_1 == 1 && nDir == 1) {
			uint8_t auPkt[] = {
			YOURMAC,
			MYMAC,
			VLD,
			LEN116,
			IFTU,
			CK16,
			MYIP,
			YOURIP,
			PORT,
			LEN216,
			0x00,0x00,
			M3RUN_ID,
			(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
			(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
			ADDRTAG
		};
		uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
		return nRet;
	} 
		
	if(P_C_INPUT_6 == 0 && nDir == 0) {
		uint8_t auPkt[] = {
			YOURMAC,
			MYMAC,
			VLD,
			LEN116,
			IFTU,
			CK16,
			MYIP,
			YOURIP,
			PORT,
			LEN216,
			0x00,0x00,
			M3RUN_ID,
			(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
			(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
			ADDRTAG
		};
		uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
		return nRet;
	}
	
	EPWM_ConfigOutputChannel(C_M3_PWM, C_M3_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M3_PWM, C_M3_PUL_MASK);//�������pwm�����
	P_C_M3_EN = 0;
	P_C_M3_DIR = nDir;
	EPWM_Start(C_M3_PWM, C_M3_PUL_MASK);
	uint8_t auPkt[] = {
			YOURMAC,
			MYMAC,
			VLD,
			LEN116,
			IFTU,
			CK16,
			MYIP,
			YOURIP,
			PORT,
			LEN216,
			0x00,0x00,
			M3RUN_ID,
			(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
			(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
			ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor3_Stop(void)
{
	EPWM_Stop(C_M3_PWM, C_M3_PUL_MASK);
	EPWM_DisableOutput(C_M3_PWM, C_M3_PUL_MASK);
	P_C_M3_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M3STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor4_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M4_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M4_PWM, C_M4_PUL_MASK);//�������pwm�����
	P_C_M4_EN = 0;
	P_C_M4_DIR = nDir;
	EPWM_Start(C_M4_PWM, C_M4_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M4RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor4_Stop(void)
{
	EPWM_Stop(C_M4_PWM, C_M4_PUL_MASK);
	EPWM_DisableOutput(C_M4_PWM, C_M4_PUL_MASK);
	P_C_M4_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M4STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor5_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M5_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M5_PWM, C_M5_PUL_MASK);//�������pwm�����
	P_C_M5_EN = 0;
	P_C_M5_DIR = nDir;
	EPWM_Start(C_M5_PWM, C_M5_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M5RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor5_Stop(void)
{
	EPWM_Stop(C_M5_PWM, C_M5_PUL_MASK);
	EPWM_DisableOutput(C_M5_PWM, C_M5_PUL_MASK);
	P_C_M5_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M5STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor6_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M6_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M6_PWM, C_M6_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M6_PWM, C_M6_PUL_MASK);//�������pwm�����
	P_C_M6_EN = 0;
	P_C_M6_DIR = nDir;
	EPWM_Start(C_M6_PWM, C_M6_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M6RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor6_Stop(void)
{
	EPWM_Stop(C_M6_PWM, C_M6_PUL_MASK);
	EPWM_DisableOutput(C_M6_PWM, C_M6_PUL_MASK);
	P_C_M6_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M6STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor7_Run(void)
{
uint32_t nFhz = gP0==0 ? CONF.M7_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M7_PWM, C_M7_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M7_PWM, C_M7_PUL_MASK);//�������pwm�����
	P_C_M7_EN = 0;
	P_C_M7_DIR = nDir;
	EPWM_Start(C_M7_PWM, C_M7_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M7RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor7_Stop(void)
{
	EPWM_Stop(C_M7_PWM, C_M7_PUL_MASK);
	EPWM_DisableOutput(C_M7_PWM, C_M7_PUL_MASK);
	P_C_M7_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M7STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor8_Run(void)
{
	uint32_t nFhz = gP0==0 ? CONF.M8_FHZ:gP0;	
	if(nFhz > FHZMAX){
		nFhz = 12000;
	}
	uint32_t nDir = gP1==0? 0:1;
	EPWM_ConfigOutputChannel(C_M8_PWM, C_M8_PUL, nFhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M8_PWM, C_M8_PUL_MASK);//�������pwm�����
	P_C_M8_EN = 0;
	P_C_M8_DIR = nDir;
	EPWM_Start(C_M8_PWM, C_M8_PUL_MASK);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		M8RUN_ID,
		(nFhz)&0xFF, (nFhz>>8)&0xFF,(nFhz>>16)&0xFF,(nFhz>>24)&0xFF,
		(nDir)&0xFF, (nDir>>8)&0xFF,(nDir>>16)&0xFF,(nDir>>24)&0xFF,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Motor8_Stop(void)
{
	EPWM_Stop(C_M8_PWM, C_M8_PUL_MASK);
	EPWM_DisableOutput(C_M8_PWM, C_M8_PUL_MASK);
	P_C_M8_EN = 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		M8STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t QEI0_Start(void)
{
	/* Set QEI counting mode as X4 Compare-counting mode,
     set maximum counter value and enable IDX, QEA and QEB input */
  QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
  /* Set counter compare value */
  //QEI_SET_CNT_CMP(QEI0, 0x10000);
  /* Enable compare function */
  //QEI_ENABLE_CNT_CMP(QEI0);
  /* Enable QEI interrupt */
  //QEI_EnableInt(QEI0, QEI_CTL_CMPIEN_Msk | QEI_CTL_OVUNIEN_Msk);
	QEI_DISABLE_NOISE_FILTER(QEI0);
  /* Start QEI function */
  QEI_Start(QEI0);
	//QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		QEI0START_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t QEI0_Stop(void)
{
	QEI_Stop(QEI0);
	QEI_Close(QEI0);
	//QEI_DisableInt(QEI0,QEI_CTL_CMPIEN_Msk | QEI_CTL_OVUNIEN_Msk);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		QEI0STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t QEI1_Start(void)
{
	/* Set QEI counting mode as X4 Compare-counting mode,
     set maximum counter value and enable IDX, QEA and QEB input */
  QEI_Open(QEI1, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
	QEI_DISABLE_NOISE_FILTER(QEI1);
  /* Start QEI function */
  QEI_Start(QEI1);
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		QEI1START_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t QEI1_Stop(void)
{
	QEI_Stop(QEI1);
	QEI_Close(QEI1);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		QEI1STOP_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
//-------------------------------------------------
uint32_t SetLaminatingPlace(void) 
{
	uint32_t u32Which = gP0;
	if(u32Which == 1) { //��Ĥ����λ��
		if(P_C_OUT_4 != gP1) {
			P_C_OUT_4 = gP1;
		}
	} else if(u32Which == 2) { // ����
		if(P_C_OUT_5 != gP1){
			P_C_OUT_5 = gP1;
		}
	} else if(u32Which == 3) { // ��ֽ����
		if(P_C_OUT_7 != gP1){
			P_C_OUT_7 = gP1;
		}
	} else if(u32Which == 4) { // �����ŷ�
		if(P_C_OUT_3 != gP1) {
			P_C_OUT_3 = gP1;
		}
	} else if(u32Which == 5) { // ��ֽ��ŷ�
		if(P_C_OUT_2 != gP1) {
			P_C_OUT_2 = gP1;
		}
	}
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		SET_LAMINATING_PLACE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;	
}
//-------------------------------------------------
uint32_t UpdateMainFeiDaBrokenFHZ_RunTime(void) 
{
	/*uint32_t u32MainCMR = gP0;
	uint32_t u32MainCNR = gP1;
	int nChange = 0;
	uint32_t u32FeiDaCMR = gP2;
	uint32_t u32FeiDaCNR = gP3;
	if(u32FeiDaCMR != 0 && u32FeiDaCNR != 0) {
		EPWM_SET_PRESCALER(C_M5_PWM,C_M5_PUL, 0);
		EPWM_SET_CNR(C_M5_PWM, C_M5_PUL, u32FeiDaCNR);
		EPWM_SET_CMR(C_M5_PWM, C_M5_PUL, u32FeiDaCMR);
		nChange++;
	}
	
	uint32_t u32BrokenCMR = gP4;
	uint32_t u32BrokenCNR = gP5;
	if(u32BrokenCMR != 0 && u32BrokenCNR != 0) {
		EPWM_SET_PRESCALER(C_M1_PWM,C_M1_PUL, 0);
		EPWM_SET_CNR(C_M1_PWM, C_M1_PUL, u32BrokenCNR);
		EPWM_SET_CMR(C_M1_PWM, C_M1_PUL, u32BrokenCMR);
		nChange++;
	}
	
	if(u32MainCMR != 0 && u32MainCNR != 0) {
		EPWM_SET_PRESCALER(C_M2_PWM,C_M2_PUL, 0);
		EPWM_SET_CNR(C_M2_PWM, C_M2_PUL, u32MainCNR);
		EPWM_SET_CMR(C_M2_PWM, C_M2_PUL, u32MainCMR);
		nChange++;
	}*/
	uint32_t u32MainCMR = gP0;
	uint32_t u32MainCNR = gP1;
	uint32_t u32FeiDaFhz = gP2;
	uint32_t u32BrokenFhz = gP3;
	uint32_t u32OutPutCMR = gP4;
	uint32_t u32OutPutCNR = gP5;
	uint32_t u32PlateFhz = gP6;
	
	int nChange = 0;
	uint32_t speedUD = 0;
	if(u32MainCNR != 0 && u32MainCMR != 0) {
		uint32_t u32NewMainFhz = FREQ_192MHZ / (u32MainCNR + 1);
		if(u32NewMainFhz >= CONF.M2_FHZ) {
			g_u16_Flag_SpeedUpOrDown = __FLAG_CHANGE_UP__;
		} else {
			g_u16_Flag_SpeedUpOrDown = __FLAG_CHANGE_DOWN__;
		}
	} else {
		g_u16_Flag_SpeedUpOrDown = __FLAG_CHANGE_NULL__;
	}
	//===========================================================
	if(g_u16_Flag_SpeedUpOrDown == __FLAG_CHANGE_UP__) { //�������
		if(u32MainCMR != 0 && u32MainCNR != 0) {
			//EPWM_SET_PRESCALER(C_M2_PWM,C_M2_PUL, 0);
			//EPWM_SET_CNR(C_M2_PWM, C_M2_PUL, u32MainCNR);
			//EPWM_SET_CMR(C_M2_PWM, C_M2_PUL, u32MainCMR);
			g_u32_New_MainCMR = u32MainCMR;
			g_u32_New_MainCNR = u32MainCNR;
			g_u16_Flag_ChangeSpeed = __FLAG_CHANGE_SPEED_BEGIN__;
			nChange++;
		}	
		if(u32FeiDaFhz != 0) {
			CONF.M5_FHZ = u32FeiDaFhz;
			CONF.FeiDaMotorRetreatFHZ = u32FeiDaFhz*2 > FHZMAX ? FHZMAX : u32FeiDaFhz*2;
			g_u16_Flag_FeiDaChangeSpeed = __FLAG_CHANGE_FEIDA_SPEED_BEGIN__;
			nChange++;
		} else {
			g_u16_Flag_FeiDaChangeSpeed = __FLAG_CHANGE_FEIDA_SPEED_FINISH__;
		}
		
		if(u32BrokenFhz != 0) {
			CONF.M1_FHZ = u32BrokenFhz;
			g_u16_Flag_BrokenChangeSpeed = __FLAG_CHANGE_BROKEN_SPEED_BEGIN__;
			nChange++;
		} else {
			g_u16_Flag_BrokenChangeSpeed = __FLAG_CHANGE_BROKEN_SPEED_FINISH__;
		}
		
		if(u32OutPutCMR != 0 && u32OutPutCNR != 0) {
			EPWM_SET_PRESCALER(C_M4_PWM,C_M4_PUL, 0);
			EPWM_SET_CNR(C_M4_PWM, C_M4_PUL, u32OutPutCNR);
			EPWM_SET_CMR(C_M4_PWM, C_M4_PUL, u32OutPutCMR);
			nChange++;
		}
		
		if(u32PlateFhz != 0) {
			CONF.M3_FHZ = u32PlateFhz;
			nChange++;
		}
		speedUD = 1;
	} 
	//===========================================================
	else if(g_u16_Flag_SpeedUpOrDown == __FLAG_CHANGE_DOWN__) { // �������
		if(u32MainCMR != 0 && u32MainCNR != 0) {
			//EPWM_SET_PRESCALER(C_M2_PWM,C_M2_PUL, 0);
			//EPWM_SET_CNR(C_M2_PWM, C_M2_PUL, u32MainCNR);
			//EPWM_SET_CMR(C_M2_PWM, C_M2_PUL, u32MainCMR);
			g_u32_New_MainCMR = u32MainCMR;
			g_u32_New_MainCNR = u32MainCNR;
			EPWM_SET_PRESCALER(C_M2_PWM,C_M2_PUL, 0);
			EPWM_SET_CNR(C_M2_PWM, C_M2_PUL, g_u32_New_MainCNR);
			EPWM_SET_CMR(C_M2_PWM, C_M2_PUL, g_u32_New_MainCMR);
			g_u16_Flag_ChangeSpeed = __FLAG_CHANGE_SPEED_FINISH__;
			CONF.M2_FHZ = FREQ_192MHZ / (g_u32_New_MainCNR + 1);
			nChange++;
		}	
		if(u32FeiDaFhz != 0) {
			CONF.M5_FHZ = u32FeiDaFhz;
			CONF.FeiDaMotorRetreatFHZ = u32FeiDaFhz*2 > FHZMAX ? FHZMAX : u32FeiDaFhz*2;
			g_u16_Flag_FeiDaChangeSpeed = __FLAG_CHANGE_FEIDA_SPEED_FINISH__;
			nChange++;
		} else {
			g_u16_Flag_FeiDaChangeSpeed = __FLAG_CHANGE_FEIDA_SPEED_FINISH__;
		}
		
		if(u32BrokenFhz != 0) {
			CONF.M1_FHZ = u32BrokenFhz;
			g_u16_Flag_BrokenChangeSpeed = __FLAG_CHANGE_BROKEN_SPEED_FINISH__;
			nChange++;
		} else {
			g_u16_Flag_BrokenChangeSpeed = __FLAG_CHANGE_BROKEN_SPEED_FINISH__;
		}
		
		if(u32OutPutCMR != 0 && u32OutPutCNR != 0) {
			EPWM_SET_PRESCALER(C_M4_PWM,C_M4_PUL, 0);
			EPWM_SET_CNR(C_M4_PWM, C_M4_PUL, u32OutPutCNR);
			EPWM_SET_CMR(C_M4_PWM, C_M4_PUL, u32OutPutCMR);
			nChange++;
		}
		
		if(u32PlateFhz != 0) {
			CONF.M3_FHZ = u32PlateFhz;
			nChange++;
		}		
		speedUD = 2;
	} 
	//===========================================================
	else if(g_u16_Flag_SpeedUpOrDown == __FLAG_CHANGE_NULL__) { // ���ı�����
		if(u32FeiDaFhz != 0) {
			CONF.M5_FHZ = u32FeiDaFhz;
			CONF.FeiDaMotorRetreatFHZ = u32FeiDaFhz*2 > FHZMAX ? FHZMAX : u32FeiDaFhz*2;
			nChange++;
		}
		if(u32BrokenFhz != 0) {
			CONF.M1_FHZ = u32BrokenFhz;
			nChange++;
		}
		if(u32OutPutCMR != 0 && u32OutPutCNR != 0) {
			EPWM_SET_PRESCALER(C_M4_PWM,C_M4_PUL, 0);
			EPWM_SET_CNR(C_M4_PWM, C_M4_PUL, u32OutPutCNR);
			EPWM_SET_CMR(C_M4_PWM, C_M4_PUL, u32OutPutCMR);
			nChange++;
		}
		if(u32PlateFhz != 0) {
			CONF.M3_FHZ = u32PlateFhz;
			nChange++;
		}
		speedUD = 3;
	}
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN120,
		IFTU,
		CK20,
		MYIP,
		YOURIP,
		PORT,
		LEN220,
		0x00,0x00,
		UPDATE_RUNTIME_MAIN_FEIDA_BROKEN_FHZ_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(nChange)&0xFF, (nChange>>8)&0xFF,(nChange>>16)&0xFF,(nChange>>24)&0xFF,
		(speedUD)&0xFF, (speedUD>>8)&0xFF,(speedUD>>16)&0xFF,(speedUD>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;		
}
//-------------------------------------------------
uint32_t SetSolenoidValue(void) 
{
	P_C_OUT_2 = gP0;
	P_C_OUT_3 = gP1;
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		TESTSETSOLENOID_VALUE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;	
}

uint32_t OUTPUT_UpdateState(void)
{
	uint32_t OPState = gP0;
	uint8_t u8StateLow = gP0 & 0xFF;//ȡ��16Ϊ
	uint8_t u8StateHig = (gP0>>8) & 0xFF;
	int out = 0;
	out = u8StateLow & 0x01;
  P_C_OUT_1 = out == 1? 0 : 1;
  out = (u8StateLow>>1) & 0x01;
  P_C_OUT_2 = out == 1? 0 : 1;
  out = (u8StateLow>>2) & 0x01;
  P_C_OUT_3 = out == 1? 0 : 1;
  out = (u8StateLow>>3) & 0x01;
  P_C_OUT_4 = out == 1? 0 : 1;
  out = (u8StateLow>>4) & 0x01;
  P_C_OUT_5 = out == 1? 0 : 1;
  out = (u8StateLow>>5) & 0x01;
	//P_C_OUT_6 = out == 1? 0 : 1;
	//out = (u8StateLow>>6) & 0x01;
  P_C_OUT_7 = out == 1? 0 : 1;
  out = (u8StateLow>>7) & 0x01;
  P_C_OUT_8 = out == 1? 0 : 1;
	
  out = u8StateHig & 0x01;
  P_C_OUT_9 = out == 1? 0 : 1;
  out = (u8StateHig>>1) & 0x01;
  P_C_OUT_10 = out == 1? 0 : 1;
  out = (u8StateHig>>2) & 0x01;
  P_C_OUT_11 = out == 1? 0 : 1;
  out = (u8StateHig>>3) & 0x01;
  P_C_OUT_12 = out == 1? 0 : 1;
  out = (u8StateHig>>4) & 0x01;
  P_C_OUT_13 = out == 1? 0 : 1;
  out = (u8StateHig>>5) & 0x01;
  P_C_OUT_14 = out == 1? 0 : 1;
  out = (u8StateHig>>6) & 0x01;
  P_C_OUT_15 = out == 1? 0 : 1;
  out = (u8StateHig>>7) & 0x01;
  P_C_OUT_16 = out == 1? 0 : 1;
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		UPDATEOUTSTATE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(OPState)&0xFF, (OPState>>8)&0xFF,(OPState>>16)&0xFF,(OPState>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t MACHINE_UpdateFHz(void)
{
	CONF.M2_FHZ = gP0 == 0?CONF.M2_FHZ:gP0;

	CONF.M1_FHZ = gP1 == 0?CONF.M1_FHZ:gP1;

	CONF.M3_FHZ = gP2 == 0?CONF.M3_FHZ:gP2;

	CONF.M4_FHZ = gP3 == 0?CONF.M4_FHZ:gP3;

	CONF.M5_FHZ = gP4 == 0?CONF.M5_FHZ:gP4;
	
	if(CONF.M5_FHZ >= CONF.FeiDaMotorRetreatFHZ) {
		CONF.FeiDaMotorRetreatFHZ = CONF.M5_FHZ + 10000; 
	}

	WriteConfig_NoSendUdp();
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, CONF.M2_FHZ, 50);//���� M2ͨ��ռ�ձȺ�Ƶ��
	EPWM_ConfigOutputChannel(C_M1_PWM, C_M1_PUL, CONF.M1_FHZ, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_ConfigOutputChannel(C_M3_PWM, C_M3_PUL, CONF.M3_FHZ, 50);//���� M3ͨ��ռ�ձȺ�Ƶ��
	EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, CONF.M4_FHZ, 50);//���� M4ͨ��ռ�ձȺ�Ƶ��
	EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, CONF.M5_FHZ, 50);//���� M5ͨ��ռ�ձȺ�Ƶ��
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN132,
		IFTU,
		CK32,
		MYIP,
		YOURIP,
		PORT,
		LEN232,
		0x00,0x00,
		UPDATEMACHINEFHZ_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(CONF.M2_FHZ)&0xFF, (CONF.M2_FHZ>>8)&0xFF,(CONF.M2_FHZ>>16)&0xFF,(CONF.M2_FHZ>>24)&0xFF,
		(CONF.M1_FHZ)&0xFF, (CONF.M1_FHZ>>8)&0xFF,(CONF.M1_FHZ>>16)&0xFF,(CONF.M1_FHZ>>24)&0xFF,
		(CONF.M3_FHZ)&0xFF, (CONF.M3_FHZ>>8)&0xFF,(CONF.M3_FHZ>>16)&0xFF,(CONF.M3_FHZ>>24)&0xFF,
		(CONF.M4_FHZ)&0xFF, (CONF.M4_FHZ>>8)&0xFF,(CONF.M4_FHZ>>16)&0xFF,(CONF.M4_FHZ>>24)&0xFF,
		(CONF.M5_FHZ)&0xFF, (CONF.M5_FHZ>>8)&0xFF,(CONF.M5_FHZ>>16)&0xFF,(CONF.M5_FHZ>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t MACHINE_UpdateDia(void)
{
	uint32_t uiInteger = gP0;
	uint32_t uiDecimal = gP1;
	float64_t fM2Dir = uiInteger + ((float64_t)uiDecimal/1000) ; 
	CONF.M2_DIA = fM2Dir == 0?CONF.M2_DIA:fM2Dir;
  
	WriteConfig_NoSendUdp();
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN120,
		IFTU,
		CK20,
		MYIP,
		YOURIP,
		PORT,
		LEN220,
		0x00,0x00,
		UPDATEMACHINEDIA_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(uiInteger)&0xFF, (uiInteger>>8)&0xFF,(uiInteger>>16)&0xFF,(uiInteger>>24)&0xFF,
		(uiDecimal)&0xFF, (uiDecimal>>8)&0xFF,(uiDecimal>>16)&0xFF,(uiDecimal>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t Before_Begin_Working(void)
{
	uint32_t uiRet = 0;
	uint32_t sendTimePulse = 0;
	uint32_t sendTime = 0;
	uint32_t bestTimePulse = 0;
	uint32_t bestTime = 0;
	
	/*if((P_C_INPUT_1 == 0 && P_C_INPUT_6 == 1) || (P_C_INPUT_1 == 0 && P_C_INPUT_6 == 0)) {
		uiRet = 1;
	}*/
	if(P_C_INPUT_1 == 0) {
			uiRet = 1;
	}
	
	uint32_t u32CareTemp = gP3; // �Ƿ��ע�¶�
	int32_t n32CurrTemp = f_GetTemperatureFrom(g_C_AD6_V);
	if(n32CurrTemp < (CONF.LaminateHeatTemperature - __TEMPERATURE_RANGE__) && u32CareTemp == 0) {
		uiRet = 2;
	}
	
	//---------------------------------------������������ľ���
	float64_t m2PM = CONF.M2_DIA * PI;//�ܳ� // 140 * 3.14159	439.8226
	uint32_t totalPulse = 40*CONF.M2_AXIS*4; // 40 * 2000 *4		
	g_f64EachPulseDis = (m2PM*1000)/totalPulse;//um/���� 1.3
	
	g_AlignSolenoidToInSensorPulse = (uint32_t)((float64_t)AlignSolenoidToInputPaperSensor/g_f64EachPulseDis); // ���뵽��ֽ������ 3cm
	g_InSensorToHitDotPulse = (uint32_t)((float64_t)InputPaperSensorToHitDotLength/g_f64EachPulseDis);	//��ֽ����������� 58.4cm
	g_HitDotToCutPaperPulse = (uint32_t)((float64_t)HitDotToCutPaperMachineLength/g_f64EachPulseDis);	// ��㵽��ֽ	11.4cm
	g_CutPaperToOutSensorPulse = (uint32_t)((float64_t)CutPaperMachineToOutputSensor/g_f64EachPulseDis);	// ��ֽ����ֽ������ 11.3cm
	g_OneCyclePulse = (uint32_t)((float64_t)OneCycleLength)/g_f64EachPulseDis;// um/���� ������������
	g_AlignSolenoidToCutPaperPulse = (uint32_t)((float64_t)(AlignSolenoidToInputPaperSensor + InputPaperSensorToHitDotLength + HitDotToCutPaperMachineLength) / g_f64EachPulseDis);
																													//30+584+140
	g_PaperLengthToPulse = (uint32_t)((float64_t)(gP0) / g_f64EachPulseDis); // ֽ��
	g_OverlapLengthToPulse = (uint32_t)((float64_t)(gP1) / g_f64EachPulseDis);	//���볤��
	g_AlignUpLengthToPulse = (uint32_t)((float64_t)(gP2) / g_f64EachPulseDis);	// �ص�����
	//---------------------------------------
	g_f64BrokenLengthPath = gP4 / 100.0;
	//---------------------------------------
	g_CalculatePaperCount = CONF.LaminatedPaperCount;//��¼�ĸ�Ĥֽ������ 
	
	sendTimePulse = g_PaperLengthToPulse - g_AlignUpLengthToPulse - g_OverlapLengthToPulse;
	sendTime = (uint32_t)((sendTimePulse/(CONF.M2_FHZ*4))*1000);
	bestTimePulse = (g_PaperLengthToPulse - g_OverlapLengthToPulse) / 2;
	bestTime = (uint32_t)((bestTimePulse/(CONF.M2_FHZ*4))*1000);
	if(gP5 != 0) {
		CONF.M2_FHZ = gP5;
		//CONF.M4_FHZ = gP5 + 30000 > FHZMAX ? FHZMAX : gP5 + 30000;
	}
	if(gP6 != 0) {
		CONF.M5_FHZ = gP6;
		CONF.FeiDaMotorRetreatFHZ = gP6 * 2 > FHZMAX ? FHZMAX : gP6 * 2;
	}
	if(gP7 != 0) {
		CONF.M1_FHZ = gP7;
	}
	if(gP8 != 0) {
		CONF.M4_FHZ = gP8;
	} 
	if(gP9 != 0) {
		CONF.M3_FHZ = gP9;
	}
	
	if(uiRet != 0) { //��������ֱ���ϱ��������
		uint8_t auPkt[] = {
			YOURMAC,
			MYMAC,
			VLD,
			LEN132,
			IFTU,
			CK32,
			MYIP,
			YOURIP,
			PORT,
			LEN232,
			0x00,0x00,
			BEFOREBEGINGWORK_ID,
			0x00,0x00,0x00,0x00,
			ADDRTAG,
			(uiRet)&0xFF, (uiRet>>8)&0xFF,(uiRet>>16)&0xFF,(uiRet>>24)&0xFF,
			(sendTime)&0xFF, (sendTime>>8)&0xFF,(sendTime>>16)&0xFF,(sendTime>>24)&0xFF,
			(bestTime)&0xFF, (bestTime>>8)&0xFF,(bestTime>>16)&0xFF,(bestTime>>24)&0xFF,
			(g_AlignSolenoidToInSensorPulse)&0xFF, (g_AlignSolenoidToInSensorPulse>>8)&0xFF,(g_AlignSolenoidToInSensorPulse>>16)&0xFF,(g_AlignSolenoidToInSensorPulse>>24)&0xFF,
			(g_AlignSolenoidToCutPaperPulse)&0xFF, (g_AlignSolenoidToCutPaperPulse>>8)&0xFF,(g_AlignSolenoidToCutPaperPulse>>16)&0xFF,(g_AlignSolenoidToCutPaperPulse>>24)&0xFF,	
		};
		EMAC_SendPkt(auPkt,sizeof(auPkt));
		return uiRet;		
	}
	return uiRet;
}

uint32_t Beging_Working(void)
{				
	if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 0) { // û��ֽ
		g_u16FlagPaperOnPlatForm = __FLAG_PAPER_DONT_ON_PLATFORM__;
	} else if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) { // ��ֽ
		g_u16FlagPaperOnPlatForm = __FLAG_PAPER_HAVE_ON_PLATFORM__;
	}
	g_OneCycleTotalPaperCount = (uint32_t)((OneCycleLength)/gP0) + 1;//һ��ѭ����ֽ����		

	//---------------------------------------����QEI
	QEI_Stop(QEI0);
	QEI_Close(QEI0);
	QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
	QEI_SET_CNT_VALUE(QEI0,QEIRecordValue);
	QEI_DISABLE_NOISE_FILTER(QEI0);
	
	QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
	uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
	QEI_ENABLE_CNT_CMP(QEI0);
	QEI_EnableInt(QEI0, QEI_CTL_OVUNIEN_Msk);
	QEI_Start(QEI0); 	
	
	if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) { //ƽ̨��û��ֽ
		FeiDaMotorForward();
		g_FeiDaMotorForwardPulse = 0;
		g_FirstPaperHeaderQEI = QEIRecordValue;
		g_LastBatchCount = 0;
		CONF.LastPaperLength = gP0;
		CONF.LastOverLapLength = gP1;
		g_u32BrokenPaperLength = 0;
	}
	else if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_HAVE_ON_PLATFORM__) { //ƽ̨����ֽ
		//-----------------------------------------------������һ��ֽ�����һ��ֽ��ʣ������
		if(CONF.LastPaperLength == 0) {
			CONF.LastPaperLength = gP0;
			g_LastPaperLength = gP0;
			g_LastPaperLengthPulse = g_PaperLengthToPulse;
		} else {
			g_LastPaperLength = CONF.LastPaperLength;//��һ���ε�ֽ����
			g_LastPaperLengthPulse = (uint32_t)((g_LastPaperLength) / g_f64EachPulseDis);
		}
		if(CONF.LastOverLapLength == 0) {//��һ�Ŷ�����
			CONF.LastOverLapLength = gP1;
			g_LastOverlapLength = gP1;
			g_LastOverlapLengthPulse = g_OverlapLengthToPulse;
		} else {
			g_LastOverlapLength = CONF.LastOverLapLength;
			g_LastOverlapLengthPulse = (uint32_t)((CONF.LastOverLapLength) / g_f64EachPulseDis);
		}		
		
		uint32_t u32LastPaperLength = CONF.LastPaperLength;
		uint32_t u32LastOverLength = CONF.LastOverLapLength;
		uint32_t u32LastLengthPulse = g_LastPaperLengthPulse;
		uint32_t u32LastOverPulse = g_LastOverlapLengthPulse;
		
		//11000
		uint32_t u32ResidueLength = u32LastPaperLength - ((AlignSolenoidToInputPaperSensor + InputPaperSensorToHitDotLength + HitDotToCutPaperMachineLength) % (u32LastPaperLength - u32LastOverLength));//ʣ�³���
		uint32_t RemainPassHalf = u32LastPaperLength / u32ResidueLength;
		if(RemainPassHalf >= 2) {//ֱ�������ɴ��� ʣ��С�� һ��
			g_FeiDaMotorForwardPulse = 0;
			FeiDaMotorForward();
		} else { //��һ���������ɴ���
			g_FeiDaMotorForwardPulse = uiQEI0 + ((u32ResidueLength - u32LastPaperLength/2) / g_f64EachPulseDis) + CONF.M8_AXIS;
		}
		
		if(u32ResidueLength <= u32LastOverLength) {//2182  11000
			g_FirstPaperHeaderQEI = uiQEI0;
		} else {
			g_FirstPaperHeaderQEI = uiQEI0 + (uint32_t)((u32ResidueLength - u32LastOverLength) / g_f64EachPulseDis);//u32ResidueLength - g_LastOverlapLengthPulse;//��ʣ�µ��ص���������		
		}
		
		uint32_t u32PaperInPlat = 0; //ֽ����
		if(((AlignSolenoidToInputPaperSensor + InputPaperSensorToHitDotLength + HitDotToCutPaperMachineLength) % (u32LastPaperLength - u32LastOverLength)) == 0) {
			u32PaperInPlat = (AlignSolenoidToInputPaperSensor + InputPaperSensorToHitDotLength + HitDotToCutPaperMachineLength) / (u32LastPaperLength - u32LastOverLength); 
		} else {
			u32PaperInPlat = (AlignSolenoidToInputPaperSensor + InputPaperSensorToHitDotLength + HitDotToCutPaperMachineLength) / (u32LastPaperLength - u32LastOverLength); 
			u32PaperInPlat++;
		}		
		if(u32PaperInPlat <__BROKEN_PAPER_QEI_MAX_COUNT__) {
			for(g_u32BrokenPaperLength = 0;g_u32BrokenPaperLength < u32PaperInPlat;g_u32BrokenPaperLength++) {
				BrokenPaperQEI[g_u32BrokenPaperLength] = uiQEI0 + (g_u32BrokenPaperLength*(u32LastLengthPulse - u32LastOverPulse) + (u32LastLengthPulse - u32LastOverPulse)*g_f64BrokenLengthPath);
			} 
		}
		g_LastBatchCount = u32PaperInPlat;
	}	
	//uint32_t OverLengthPulse = g_LastPaperLengthPulse - ((g_InSensorToHitDotPulse + g_HitDotToCutPaperPulse - g_AlignSolenoidToInSensorPulse) % (g_LastPaperLengthPulse - g_LastOverlapLengthPulse));//��ֽ������֮��ʣ�µĳ���
	//--------------------------------------- �������
	
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, CONF.M2_FHZ, 50);//������
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 0;
	P_C_M2_DIR = 0;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
	
	EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, CONF.M4_FHZ, 50);//��ֽ���
	EPWM_EnableOutput(C_M4_PWM, C_M4_PUL_MASK);
	P_C_M4_EN = 0;
	P_C_M4_DIR = 0;
	EPWM_Start(C_M4_PWM, C_M4_PUL_MASK);
	//---------------------------------------��������
	if(P_C_OUT_5 == 1) {
		P_C_OUT_5 = 0;
	}
	//---------------------------------------	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN132,
		IFTU,
		CK32,
		MYIP,
		YOURIP,
		PORT,
		LEN232,
		0x00,0x00,
		BEGINWORK_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_PaperLengthToPulse)&0xFF, (g_PaperLengthToPulse>>8)&0xFF,(g_PaperLengthToPulse>>16)&0xFF,(g_PaperLengthToPulse>>24)&0xFF,
		(g_OverlapLengthToPulse)&0xFF, (g_OverlapLengthToPulse>>8)&0xFF,(g_OverlapLengthToPulse>>16)&0xFF,(g_OverlapLengthToPulse>>24)&0xFF,
		(g_AlignUpLengthToPulse)&0xFF, (g_AlignUpLengthToPulse>>8)&0xFF,(g_AlignUpLengthToPulse>>16)&0xFF,(g_AlignUpLengthToPulse>>24)&0xFF,
		(g_LastBatchCount)&0xFF, (g_LastBatchCount>>8)&0xFF,(g_LastBatchCount>>16)&0xFF,(g_LastBatchCount>>24)&0xFF,	
		(g_FirstPaperHeaderQEI)&0xFF, (g_FirstPaperHeaderQEI>>8)&0xFF,(g_FirstPaperHeaderQEI>>16)&0xFF,(g_FirstPaperHeaderQEI>>24)&0xFF,		
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t Finish_Working(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		FINISHWORK_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t HeatLaminationRoll(void)
{
	if(gP0 == 0) { // ����
		EPWM_ConfigOutputChannel(C_HEAT_PWM, C_HEAT_PUL, CONF.Heat_Fhz, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
		EPWM_EnableOutput(C_HEAT_PWM, C_HEAT_PUL_MASK);//�������pwm�����
		EPWM_Start(C_HEAT_PWM, C_HEAT_PUL_MASK);
		g_u32_Flag_HeatingState = __HEAT_STATE_HEATING__;
	} else if(gP0 == 1) {//ֹͣ����
		EPWM_Stop(C_HEAT_PWM,C_HEAT_PUL_MASK);
		EPWM_ForceStop(C_HEAT_PWM,C_HEAT_PUL_MASK);
		EPWM_DisableOutput(C_HEAT_PWM,C_HEAT_PUL_MASK);	
		g_u32_Flag_HeatingState = __HEAT_STATE_CANCEL__;
	}
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		LAMINATINGROLLHEAT_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t FeiDaMotor_UpdateFHz(void)
{
	CONF.FeiDaMotorRetreatFHZ = gP0 == 0?CONF.FeiDaMotorRetreatFHZ:gP0;
	if(CONF.M5_FHZ > CONF.FeiDaMotorRetreatFHZ) {
		CONF.FeiDaMotorRetreatFHZ = CONF.M5_FHZ + 10000;
		if(CONF.FeiDaMotorRetreatFHZ >= FHZMAX) {
			CONF.FeiDaMotorRetreatFHZ = FHZMAX;
			CONF.M5_FHZ = FHZMAX;
		}
	}
	WriteConfig_NoSendUdp();
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		UPDATEFEIDARETREAT_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t FMDUploadAlarm(void)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		UPLOADWARNING_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_AlarmCode)&0xFF, (g_AlarmCode>>8)&0xFF,(g_AlarmCode>>16)&0xFF,(g_AlarmCode>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

//---------------------------------------------------------------
uint32_t TestHeatDuty(void) 
{
	uint32_t u32Fhz = gP0;
	uint32_t u32Duty = gP1;
	
	EPWM_ConfigOutputChannel(C_HEAT_PWM, C_HEAT_PUL, u32Fhz, u32Duty);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_HEAT_PWM, C_HEAT_PUL_MASK);//�������pwm�����
	EPWM_Start(C_HEAT_PWM, C_HEAT_PUL_MASK);
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		TESTTEMP_DUTY_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
uint32_t TestSheetPaper(void) 
{
	if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 0) { // û��ֽ
		g_u16FlagPaperOnPlatForm = __FLAG_PAPER_DONT_ON_PLATFORM__;
	} else if(P_C_OUT_15 == 0 && P_C_INPUT_2 == 1) { // ��ֽ
		g_u16FlagPaperOnPlatForm = __FLAG_PAPER_HAVE_ON_PLATFORM__;
	}
	//---------------------------------------������������ľ���
	float64_t m2PM = CONF.M2_DIA * PI;//�ܳ� // 140 * 3.14159
	uint32_t totalPulse = 40*CONF.M2_AXIS*4; // 40 * 140*4
	g_f64EachPulseDis = (m2PM*1000)/totalPulse;//um/����
	
	g_AlignSolenoidToInSensorPulse = (uint32_t)((float64_t)AlignSolenoidToInputPaperSensor/g_f64EachPulseDis); // ���뵽��ֽ������ 3cm
	g_InSensorToHitDotPulse = (uint32_t)((float64_t)InputPaperSensorToHitDotLength/g_f64EachPulseDis);	//��ֽ����������� 58.4cm
	g_HitDotToCutPaperPulse = (uint32_t)((float64_t)HitDotToCutPaperMachineLength/g_f64EachPulseDis);	// ��㵽��ֽ	11.4cm
	g_CutPaperToOutSensorPulse = (uint32_t)((float64_t)CutPaperMachineToOutputSensor/g_f64EachPulseDis);	// ��ֽ����ֽ������ 11.3cm
	g_OneCyclePulse = (uint32_t)((float64_t)OneCycleLength)/g_f64EachPulseDis;// um/���� ������������
	
	g_PaperLengthToPulse = (uint32_t)((float64_t)(gP0) / g_f64EachPulseDis); // ֽ��
	g_OverlapLengthToPulse = (uint32_t)((float64_t)(gP1) / g_f64EachPulseDis);	//���볤��
	g_AlignUpLengthToPulse = (uint32_t)((float64_t)(gP2) / g_f64EachPulseDis);	// �ص�����
	//---------------------------------------
	g_f64BrokenLengthPath = gP4 / 100.0;
	g_u32BrokenPaperLength = 0;
	//---------------------------------------
	g_OneCycleTotalPaperCount = (uint32_t)((OneCycleLength)/gP0) + 1;//һ��ѭ����ֽ����		
	
	g_CalculatePaperCount = CONF.LaminatedPaperCount;//��¼�ĸ�Ĥֽ������
	if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) { //ƽ̨��û��ֽ
		FeiDaMotorForward();
		g_FeiDaMotorForwardPulse = 0;
		g_FirstPaperHeaderQEI = QEIRecordValue;
		g_LastBatchCount = 0;
		//---------------------------------------����QEI
		QEI_Stop(QEI0);
		QEI_Close(QEI0);
		QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
		QEI_SET_CNT_VALUE(QEI0,QEIRecordValue);
		QEI_DISABLE_NOISE_FILTER(QEI0);
			
		QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
		uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
		QEI_ENABLE_CNT_CMP(QEI0);
		QEI_EnableInt(QEI0, QEI_CTL_OVUNIEN_Msk);
		QEI_Start(QEI0); 			
	} else if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_HAVE_ON_PLATFORM__) { //ƽ̨����ֽ
		g_LastBatchCount = 0;
	}			
	uint32_t uiRet = 0;
	uint32_t sendTimePulse = 0;
	uint32_t sendTime = 0;
	uint32_t bestTimePulse = 0;
	uint32_t bestTime = 0;
	if((P_C_INPUT_1 == 0 && P_C_INPUT_6 == 1) || (P_C_INPUT_1 == 0 && P_C_INPUT_6 == 0)) {
		uiRet = 1;	
	}
	uint32_t u32CareTemp = gP3; // �Ƿ��ע�¶�
	int32_t n32CurrTemp = f_GetTemperatureFrom(g_C_AD6_V);
	if(n32CurrTemp < (CONF.LaminateHeatTemperature - __TEMPERATURE_RANGE__) && u32CareTemp == 0) {
		uiRet = 2;
	}	
	sendTimePulse = g_PaperLengthToPulse - g_AlignUpLengthToPulse - g_OverlapLengthToPulse;
	sendTime = (uint32_t)((sendTimePulse/(CONF.M2_FHZ*4))*1000);
	bestTimePulse = (g_PaperLengthToPulse - g_OverlapLengthToPulse) / 2;
	bestTime = (uint32_t)((bestTimePulse/(CONF.M2_FHZ*4))*1000);
	if(CONF.M5_FHZ < bestTime) {
		uiRet = 3;
	}
	
	//--------------------------------------- �������
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, CONF.M2_FHZ, 50);//������
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 0; 	
	P_C_M2_DIR = 0;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
		
	EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, CONF.M4_FHZ, 50);//��ֽ���
	EPWM_EnableOutput(C_M4_PWM, C_M4_PUL_MASK);
	P_C_M4_EN = 0;
	P_C_M4_DIR = 0;
	EPWM_Start(C_M4_PWM, C_M4_PUL_MASK);
	//---------------------------------------��������
	if(P_C_OUT_5 == 1) {
		P_C_OUT_5 = 0;
	}
	//---------------------------------------	
	if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_DONT_ON_PLATFORM__) {
	
	} else if(g_u16FlagPaperOnPlatForm == __FLAG_PAPER_HAVE_ON_PLATFORM__){
		QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
		uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
		g_u32_Sheet_Record_DeviationQEI = uiQEI0 - g_u32_Sheet_Record_LastStopQEI;
	}

	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN124,
		IFTU,
		CK24,
		MYIP,
		YOURIP,
		PORT,
		LEN224,
		0x00,0x00,
		TEST_SHEET_PAPER_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(g_PaperLengthToPulse)&0xFF, (g_PaperLengthToPulse>>8)&0xFF,(g_PaperLengthToPulse>>16)&0xFF,(g_PaperLengthToPulse>>24)&0xFF,
		(g_OverlapLengthToPulse)&0xFF, (g_OverlapLengthToPulse>>8)&0xFF,(g_OverlapLengthToPulse>>16)&0xFF,(g_OverlapLengthToPulse>>24)&0xFF,
		(g_AlignUpLengthToPulse)&0xFF, (g_AlignUpLengthToPulse>>8)&0xFF,(g_AlignUpLengthToPulse>>16)&0xFF,(g_AlignUpLengthToPulse>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
//---------------------------------------------------------------
uint32_t TestFeiDaFhzWithMotor2(void)
{
	QEI_Stop(QEI0);
	QEI_Close(QEI0);
	QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
	QEI_SET_CNT_VALUE(QEI0,QEIRecordValue);
	QEI_DISABLE_NOISE_FILTER(QEI0);

	QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
	QEI_EnableInt(QEI0, QEI_CTL_OVUNIEN_Msk);
	QEI_Start(QEI0);
	
	uint32_t nFhz2 = gP0;
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, gP0, 50);//������
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 0;
	P_C_M2_DIR = 0;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
	
	uint32_t nFhz5 = gP1;
	EPWM_ConfigOutputChannel(C_M5_PWM, C_M5_PUL, gP1, 50);
	EPWM_EnableOutput(C_M5_PWM, C_M5_PUL_MASK);
	P_C_M5_EN = 0;
	P_C_M5_DIR = 0;
	EPWM_Start(C_M5_PWM, C_M5_PUL_MASK);

	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		TESTFEIDAFHZ_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t TestBrokenFhzWithMotot1(void) 
{
	QEI_Stop(QEI0);
	QEI_Close(QEI0);
	QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
	QEI_SET_CNT_VALUE(QEI0,QEIRecordValue);
	QEI_DISABLE_NOISE_FILTER(QEI0);

	QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
	QEI_EnableInt(QEI0, QEI_CTL_OVUNIEN_Msk);
	QEI_Start(QEI0);
	
	uint32_t nFhz2 = gP0;
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, gP0, 50);//������
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 0;
	P_C_M2_DIR = 0;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
	
	uint32_t nFhz1 = gP1;
	EPWM_ConfigOutputChannel(C_M1_PWM, C_M1_PUL, nFhz1, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M1_PWM, C_M1_PUL_MASK);//�������pwm�����
	P_C_M1_EN = 0;
	P_C_M1_DIR = 0;
	EPWM_Start(C_M1_PWM, C_M1_PUL_MASK);
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		TESTBROKENFHZ_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

//---------------------------------------------------------------
uint32_t UploadStateNow(uint32_t uiStateID)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		(uiStateID)&0xFF, (uiStateID>>8)&0xFF,(uiStateID>>16)&0xFF,(uiStateID>>24)&0xFF,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t UploadStateNow_WithOneParam(uint32_t stateID, uint32_t param1) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		(stateID)&0xFF, (stateID>>8)&0xFF,(stateID>>16)&0xFF,(stateID>>24)&0xFF,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(param1)&0xFF, (param1>>8)&0xFF,(param1>>16)&0xFF,(param1>>24)&0xFF,	
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t UploadStateNow_WithTwoParam(uint32_t stateID, uint32_t param1, uint32_t param2) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN120,
		IFTU,
		CK20,
		MYIP,
		YOURIP,
		PORT,
		LEN220,
		0x00,0x00,
		(stateID)&0xFF, (stateID>>8)&0xFF,(stateID>>16)&0xFF,(stateID>>24)&0xFF,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(param1)&0xFF, (param1>>8)&0xFF,(param1>>16)&0xFF,(param1>>24)&0xFF,	
		(param2)&0xFF, (param2>>8)&0xFF,(param2>>16)&0xFF,(param2>>24)&0xFF,	
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t UploadStateNowAndNetOperatot(uint32_t uiStateID, uint32_t nextCmdID) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN116,
		IFTU,
		CK16,
		MYIP,
		YOURIP,
		PORT,
		LEN216,
		0x00,0x00,
		(uiStateID)&0xFF, (uiStateID>>8)&0xFF,(uiStateID>>16)&0xFF,(uiStateID>>24)&0xFF,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(nextCmdID)&0xFF, (nextCmdID>>8)&0xFF,(nextCmdID>>16)&0xFF,(nextCmdID>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}

uint32_t UpLoadAlignBlockSolenoidState(uint32_t FeederState, uint32_t AlignState, uint32_t EnCodedrCount)
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN124,
		IFTU,
		CK24,
		MYIP,
		YOURIP,
		PORT,
		LEN224,
		0x00,0x00,
		ALIGNBLOCKSOLENOIDSTATE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG,
		(FeederState)&0xFF, (FeederState>>8)&0xFF,(FeederState>>16)&0xFF,(FeederState>>24)&0xFF,
		(AlignState)&0xFF, (AlignState>>8)&0xFF,(AlignState>>16)&0xFF,(AlignState>>24)&0xFF,
		(EnCodedrCount)&0xFF, (EnCodedrCount>>8)&0xFF,(EnCodedrCount>>16)&0xFF,(EnCodedrCount>>24)&0xFF,
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;
}
//-------------------------------------------------
uint32_t TestRunMotorSetCMRCNR(void) 
{
	uint32_t u32Prescaler = gP0;
	uint32_t u32CNR = gP1;
	uint32_t u32CMR = gP2;
	
	/*
	EPWM_ConfigOutputChannel(C_M4_PWM, C_M4_PUL, 10000, 50);//���� M1ͨ��ռ�ձȺ�Ƶ��
	EPWM_EnableOutput(C_M4_PWM, C_M4_PUL_MASK);//�������pwm�����
	P_C_M4_EN = 0;
	P_C_M4_DIR = 0;
	EPWM_Start(C_M4_PWM, C_M4_PUL_MASK);
	*/
	
	EPWM_SET_PRESCALER(C_M4_PWM, C_M4_PUL, u32Prescaler);
	EPWM_SET_CNR(C_M4_PWM, C_M4_PUL, u32CNR);
	EPWM_SET_CMR(C_M4_PWM, C_M4_PUL, u32CMR);
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		RUN_MOTOR_CNR_CMR_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;		
}
uint32_t TestForMachineSpeed(void) 
{
	uint32_t u32MainSpeed = gP0;
	g_TestMachineSpeedTime = gP1;
	EPWM_ConfigOutputChannel(C_M2_PWM, C_M2_PUL, u32MainSpeed, 50);//������
	EPWM_EnableOutput(C_M2_PWM, C_M2_PUL_MASK);
	P_C_M2_EN = 0;
	P_C_M2_DIR = 0;
	EPWM_Start(C_M2_PWM, C_M2_PUL_MASK);
	
	//---------------------------------------����QEI
	QEI_Stop(QEI0);
	QEI_Close(QEI0);
	QEI_Open(QEI0, QEI_CTL_X4_FREE_COUNTING_MODE, 0xFFFFFFFF);
	QEI_SET_CNT_VALUE(QEI0,0);
	QEI_DISABLE_NOISE_FILTER(QEI0);
	
	QEI_ENABLE_HOLD_TRG_SRC(QEI0,QEI_CTL_HOLDCNT_Msk);
	uint32_t uiQEI0 = QEI_GET_HOLD_VALUE(QEI0);
	QEI_ENABLE_CNT_CMP(QEI0);
	QEI_EnableInt(QEI0, QEI_CTL_OVUNIEN_Msk);
	QEI_Start(QEI0); 
	
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		TEST_MACHINE_SPEED_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;			
}

uint32_t MachineInitialize(void) 
{
	uint8_t auPkt[] = {
		YOURMAC,
		MYMAC,
		VLD,
		LEN112,
		IFTU,
		CK12,
		MYIP,
		YOURIP,
		PORT,
		LEN212,
		0x00,0x00,
		MACHINEINITIALIZE_ID,
		0x00,0x00,0x00,0x00,
		ADDRTAG
	};
	uint32_t nRet = EMAC_SendPkt(auPkt,sizeof(auPkt));
	return nRet;			
}

//-------------------------------------------------

